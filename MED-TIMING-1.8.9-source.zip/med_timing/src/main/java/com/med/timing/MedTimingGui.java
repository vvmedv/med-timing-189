package com.med.timing;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;

public class MedTimingGui extends GuiScreen {
    private int centerX;
    private int top;

    @Override
    public void initGui() {
        buttonList.clear();
        centerX = width / 2;
        top = height / 2 - 85;
        int w = 210, h = 20, gap = 24;
        buttonList.add(new GuiButton(0, centerX - w/2, top, w, h, "Aim Assist: " + (MedTiming.aimAssist ? "ON" : "OFF")));
        buttonList.add(new GuiButton(1, centerX - w/2, top + gap, w, h, "Target Box: " + (MedTiming.showBox ? "ON" : "OFF")));
        buttonList.add(new GuiButton(2, centerX - w/2, top + gap*2, w, h, "HUD: " + (MedTiming.showHud ? "ON" : "OFF")));
        buttonList.add(new GuiButton(3, centerX - w/2, top + gap*3, w, h, "Ping: " + (MedTiming.showPing ? "ON" : "OFF")));
        buttonList.add(new GuiButton(4, centerX - w/2, top + gap*4, w, h, "Aim Strength: " + Math.round(MedTiming.aimStrength * 100) + "%  (- / +)"));
        buttonList.add(new GuiButton(5, centerX - w/2, top + gap*5, w, h, "Timing Offset: " + MedTiming.timingOffsetMs + " ms  (- / +)"));
        buttonList.add(new GuiButton(6, centerX - w/2, top + gap*6, w, h, "Alert Window: " + MedTiming.alertSeconds + " seconds"));
        buttonList.add(new GuiButton(7, centerX - w/2, top + gap*7, w, h, "Sound Effects: " + (MedTiming.soundEffects ? "ON" : "OFF")));
        buttonList.add(new GuiButton(8, centerX - 105, top + gap*8 + 4, 100, h, "Done"));
        buttonList.add(new GuiButton(9, centerX + 5, top + gap*8 + 4, 100, h, "Reset"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: MedTiming.aimAssist = !MedTiming.aimAssist; break;
            case 1: MedTiming.showBox = !MedTiming.showBox; break;
            case 2: MedTiming.showHud = !MedTiming.showHud; break;
            case 3: MedTiming.showPing = !MedTiming.showPing; break;
            case 4:
                if (isShiftKeyDown()) MedTiming.aimStrength = Math.max(0.05F, MedTiming.aimStrength - 0.05F);
                else MedTiming.aimStrength = Math.min(1.0F, MedTiming.aimStrength + 0.05F);
                break;
            case 5:
                if (isShiftKeyDown()) MedTiming.timingOffsetMs = Math.max(-10, MedTiming.timingOffsetMs - 1);
                else MedTiming.timingOffsetMs = Math.min(10, MedTiming.timingOffsetMs + 1);
                break;
            case 6: MedTiming.alertSeconds = MedTiming.alertSeconds == 3 ? 5 : (MedTiming.alertSeconds == 5 ? 1 : 3); break;
            case 7: MedTiming.soundEffects = !MedTiming.soundEffects; break;
            case 8: mc.displayGuiScreen(null); break;
            case 9:
                MedTiming.aimAssist = true; MedTiming.showBox = true; MedTiming.showHud = true;
                MedTiming.showPing = true; MedTiming.aimStrength = 0.35F; MedTiming.timingOffsetMs = 0;
                MedTiming.alertSeconds = 3; MedTiming.soundEffects = false;
                break;
        }
        initGui();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawRect(width / 2 - 125, height / 2 - 108, width / 2 + 125, height / 2 + 124, 0xD0101010);
        drawCenteredString(fontRendererObj, "MED TIMING SETTINGS", width / 2, height / 2 - 104, 0xFFFFFF);
        drawCenteredString(fontRendererObj, "Hold SHIFT and click strength/offset to decrease", width / 2, height / 2 + 112, 0xAAAAAA);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1 || keyCode == 211) { mc.displayGuiScreen(null); return; }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
