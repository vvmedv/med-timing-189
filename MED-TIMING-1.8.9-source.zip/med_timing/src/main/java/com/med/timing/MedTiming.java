package com.med.timing;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;

@Mod(modid = MedTiming.MODID, name = MedTiming.NAME, version = MedTiming.VERSION, acceptedMinecraftVersions = "[1.8.9]")
public class MedTiming {
    public static final String MODID = "medtiming";
    public static final String NAME = "MED TIMING";
    public static final String VERSION = "1.0.0";
    public static final Minecraft MC = Minecraft.getMinecraft();
    public static KeyBinding toggleKey;
    public static KeyBinding settingsKey;

    public static boolean enabled = false;
    public static boolean showBox = true;
    public static boolean showHud = true;
    public static boolean showPing = true;
    public static boolean aimAssist = true;
    public static boolean soundEffects = false;
    public static float aimStrength = 0.35F;
    public static int timingOffsetMs = 0;
    public static int alertSeconds = 3;
    public static EntityPlayer target;
    public static int timerSeconds = -1;
    private static final Pattern NUMBER = Pattern.compile("(\\d+)");

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        toggleKey = new KeyBinding("MED TIMING: Toggle (Q)", Keyboard.KEY_Q, "MED TIMING");
        settingsKey = new KeyBinding("MED TIMING: Settings (Delete)", Keyboard.KEY_DELETE, "MED TIMING");
        ClientRegistry.registerKeyBinding(toggleKey);
        ClientRegistry.registerKeyBinding(settingsKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (toggleKey.isPressed()) {
            enabled = !enabled;
            if (!enabled) target = null;
            if (soundEffects && MC.thePlayer != null) {
                MC.thePlayer.playSound("random.click", 0.6F, enabled ? 1.4F : 0.8F);
            }
        }
        if (settingsKey.isPressed() && MC.thePlayer != null) {
            MC.displayGuiScreen(new MedTimingGui());
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || MC.theWorld == null || MC.thePlayer == null) return;
        timerSeconds = readTntTimer();
        if (!enabled) { target = null; return; }
        target = findTarget();
        if (aimAssist && target != null) applyAim(target);
    }

    private EntityPlayer findTarget() {
        EntityPlayer best = null;
        double bestDistance = 4.2D;
        for (Object obj : MC.theWorld.playerEntities) {
            if (!(obj instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) obj;
            if (p == MC.thePlayer || !p.isEntityAlive() || p.isInvisible()) continue;
            double d = MC.thePlayer.getDistanceToEntity(p);
            if (d < bestDistance) { bestDistance = d; best = p; }
        }
        return best;
    }

    private void applyAim(EntityPlayer p) {
        EntityPlayerSP me = MC.thePlayer;
        double dx = p.posX - me.posX;
        double dz = p.posZ - me.posZ;
        double dy = (p.posY + p.getEyeHeight() * 0.75D) - (me.posY + me.getEyeHeight());
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float desiredYaw = (float)(Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0F;
        float desiredPitch = (float)(-(Math.atan2(dy, horizontal) * 180.0D / Math.PI));
        float factor = MathHelper.clamp_float(aimStrength, 0.05F, 1.0F);
        me.rotationYaw += MathHelper.wrapAngleTo180_float(desiredYaw - me.rotationYaw) * factor;
        me.rotationPitch += (desiredPitch - me.rotationPitch) * factor;
        me.rotationPitch = MathHelper.clamp_float(me.rotationPitch, -90.0F, 90.0F);
    }

    private int readTntTimer() {
        try {
            if (MC.theWorld.getScoreboard() == null) return -1;
            ScoreObjective objective = MC.theWorld.getScoreboard().getObjectiveInDisplaySlot(1);
            if (objective == null) return -1;
            Collection<Score> scores = MC.theWorld.getScoreboard().getSortedScores(objective);
            for (Score score : scores) {
                String line = ScorePlayerTeam.formatPlayerName(MC.theWorld.getScoreboard().getPlayersTeam(score.getPlayerName()), score.getPlayerName());
                line = net.minecraft.util.StringUtils.stripControlCodes(line);
                if (line.toLowerCase().contains("explosion in")) {
                    Matcher m = NUMBER.matcher(line);
                    int last = -1;
                    while (m.find()) last = Integer.parseInt(m.group(1));
                    return last;
                }
            }
        } catch (Exception ignored) { }
        return -1;
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        if (!enabled || !showBox || target == null || MC.thePlayer == null) return;
        double x = target.lastTickPosX + (target.posX - target.lastTickPosX) * event.partialTicks - MC.getRenderManager().viewerPosX;
        double y = target.lastTickPosY + (target.posY - target.lastTickPosY) * event.partialTicks - MC.getRenderManager().viewerPosY;
        double z = target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * event.partialTicks - MC.getRenderManager().viewerPosZ;
        AxisAlignedBB bb = target.getEntityBoundingBox().offset(x - target.posX, y - target.posY, z - target.posZ).expand(0.04D, 0.04D, 0.04D);
        boolean urgent = timerSeconds >= 0 && timerSeconds <= alertSeconds;
        float r = urgent ? 1.0F : 0.92F;
        float g = urgent ? 0.12F : 0.92F;
        float b = urgent ? 0.12F : 0.92F;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.glLineWidth(1.8F);
        RenderGlobal.drawSelectionBoundingBox(bb, r, g, b, 0.95F);
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
    }

    @SubscribeEvent
    public void onHud(RenderGameOverlayEvent.Text event) {
        if (!enabled || !showHud) return;
        int x = 8, y = 8;
        MC.fontRendererObj.drawStringWithShadow("MED TIMING", x, y, 0xFFFFFF);
        MC.fontRendererObj.drawStringWithShadow("Status: ON", x, y + 11, 0xAAAAAA);
        if (showPing && MC.thePlayer != null) {
            int ping = -1;
            try {
                net.minecraft.client.network.NetworkPlayerInfo info = MC.getNetHandler().getPlayerInfo(MC.thePlayer.getUniqueID());
                if (info != null) ping = info.getResponseTime();
            } catch (Exception ignored) { }
            MC.fontRendererObj.drawStringWithShadow("Ping: " + (ping < 0 ? "--" : ping + " ms"), x, y + 22, 0xFFFFFF);
        }
        String t = timerSeconds < 0 ? "TNT: --" : "TNT: " + timerSeconds + "s";
        int color = timerSeconds >= 0 && timerSeconds <= alertSeconds ? 0xFF5555 : 0xFFFFFF;
        MC.fontRendererObj.drawStringWithShadow(t, x, y + 33, color);
        MC.fontRendererObj.drawStringWithShadow("Offset: " + timingOffsetMs + " ms", x, y + 44, 0xAAAAAA);
    }
}
