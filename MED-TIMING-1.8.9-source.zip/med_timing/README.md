# MED TIMING 1.8.9 (source project)

A Forge 1.8.9 client-side mod prototype under Med's name.

## Intended controls
- `Q`: toggle the overlay/targeting system.
- `Delete`: open settings.
- `Esc` or `Delete`: close settings.

## Included prototype features
- Target selection among nearby `EntityPlayer` entities (4.2-block range).
- Optional smooth camera rotation toward the selected target, toggleable in settings.
- White target box, turning red when the detected scoreboard line `Explosion in` reaches the configured alert window.
- HUD with target-system status, ping, TNT seconds, and offset value.
- Settings screen for Aim Assist toggle/strength, box, HUD, ping, timing offset, alert window, and sound toggle.

## Build
This project uses the legacy ForgeGradle 2.1 toolchain for Minecraft 1.8.9. Build with a compatible JDK/Gradle environment and network access to the Forge Maven repository:

```bash
gradle setupDecompWorkspace
 gradle build
```

The resulting JAR should appear in `build/libs/`.

## Important implementation notes
- This is a source prototype, not a tested or compiled JAR.
- The scoreboard parser depends on the server exposing a sidebar line containing `Explosion in` and a numeric value.
- `Timing Offset` is exposed in the settings/HUD but is not wired to automate attack packets; it is a displayed configuration value only.
- Target selection treats nearby visible player entities as candidates. Test only in an environment where you are authorized to use this behavior.
